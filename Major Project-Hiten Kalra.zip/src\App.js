import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { io } from "socket.io-client";
import "./App.css";

const SOCKET_URL = process.env.REACT_APP_SOCKET_URL || "http://localhost:5000";
const CANVAS_WIDTH = 3600;
const CANVAS_HEIGHT = 2200;
const TOOLS = ["pen", "eraser", "rectangle", "circle", "line", "text", "pan"];
const COLORS = ["#111827", "#2563eb", "#16a34a", "#f97316", "#dc2626", "#9333ea"];
const ICE_SERVERS = [{ urls: "stun:stun.l.google.com:19302" }];

const socket = io(SOCKET_URL, {
  autoConnect: false,
  reconnection: true,
  reconnectionAttempts: Infinity,
  reconnectionDelay: 600,
  reconnectionDelayMax: 3500,
  timeout: 10000,
  transports: ["websocket", "polling"],
});

const makeId = () =>
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;

const reportNonFatal = (context, error) => {
  const message = error?.message || error?.reason || String(error || "Unknown error");
  console.warn(`${context}: ${message}`, error);
  return message;
};

const safeAsync = (context, handler) => (...args) => {
  Promise.resolve(handler(...args)).catch((error) => reportNonFatal(context, error));
};

const avatarFor = (name = "Guest") =>
  name
    .trim()
    .split(/\s+/)
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase() || "GC";

const getCanvasPoint = (event, canvas) => {
  const rect = canvas.getBoundingClientRect();
  const widthRatio = canvas.width / rect.width;
  const heightRatio = canvas.height / rect.height;

  // getBoundingClientRect already includes CSS translate/scale transforms.
  // Mapping through the rendered rect keeps mouse/touch coordinates correct
  // while the infinite canvas is panned and zoomed.
  return {
    x: (event.clientX - rect.left) * widthRatio,
    y: (event.clientY - rect.top) * heightRatio,
  };
};

function App() {
  const params = useMemo(() => new URLSearchParams(window.location.search), []);
  const [roomId, setRoomId] = useState(params.get("room") || "strategy-room");
  const [displayName, setDisplayName] = useState(
    localStorage.getItem("whiteboard-name") || "Guest Collaborator"
  );
  const [joined, setJoined] = useState(false);
  const [status, setStatus] = useState("Idle");
  const [errorMessage, setErrorMessage] = useState("");
  const [participants, setParticipants] = useState([]);
  const [messages, setMessages] = useState([]);
  const [messageDraft, setMessageDraft] = useState("");
  const [activePanel, setActivePanel] = useState("chat");
  const [elements, setElements] = useState([]);
  const [redoStack, setRedoStack] = useState([]);
  const [tool, setTool] = useState("pen");
  const [color, setColor] = useState("#2563eb");
  const [strokeSize, setStrokeSize] = useState(6);
  const [darkMode, setDarkMode] = useState(true);
  const [mediaState, setMediaState] = useState({
    mic: false,
    camera: false,
    sharing: false,
    hand: false,
  });
  const [remoteStreams, setRemoteStreams] = useState({});
  const [cursors, setCursors] = useState({});
  const [activeSpeaker, setActiveSpeaker] = useState("");
  const [view, setView] = useState({ x: -980, y: -560, zoom: 0.82 });

  const canvasRef = useRef(null);
  const localVideoRef = useRef(null);
  const localStreamRef = useRef(null);
  const peerConnectionsRef = useRef({});
  const currentElementRef = useRef(null);
  const remotePreviewsRef = useRef({});
  const panRef = useRef(null);
  const renderFrameRef = useRef(null);
  const elementsRef = useRef([]);
  const viewRef = useRef(view);
  const participantsRef = useRef([]);
  const joinedRef = useRef(false);
  const roomRef = useRef(roomId);
  const profileRef = useRef({ name: displayName, avatar: avatarFor(displayName) });
  const cursorThrottleRef = useRef(0);

  const roomLink = useMemo(() => {
    const url = new URL(window.location.href);
    url.searchParams.set("room", roomId || "strategy-room");
    return url.toString();
  }, [roomId]);

  useEffect(() => {
    elementsRef.current = elements;
  }, [elements]);

  useEffect(() => {
    viewRef.current = view;
  }, [view]);

  useEffect(() => {
    participantsRef.current = participants;
  }, [participants]);

  useEffect(() => {
    joinedRef.current = joined;
  }, [joined]);

  useEffect(() => {
    roomRef.current = roomId;
  }, [roomId]);

  useEffect(() => {
    profileRef.current = { name: displayName, avatar: avatarFor(displayName) };
  }, [displayName]);

  const setRoomElements = useCallback((nextElements) => {
    elementsRef.current = nextElements;
    setElements(nextElements);
  }, []);

  const drawElement = useCallback((ctx, element) => {
    if (!element) return;

    ctx.save();
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.lineWidth = Number(element.size) || 4;
    ctx.strokeStyle = element.color || "#2563eb";
    ctx.fillStyle = element.color || "#2563eb";

    if (element.tool === "eraser") {
      ctx.globalCompositeOperation = "destination-out";
      ctx.lineWidth = (Number(element.size) || 4) * 2.2;
    }

    if (element.tool === "pen" || element.tool === "eraser") {
      const points = element.points || [];
      if (points.length > 1) {
        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);
        points.slice(1).forEach((point) => ctx.lineTo(point.x, point.y));
        ctx.stroke();
      }
    }

    if (element.tool === "rectangle") {
      ctx.strokeRect(element.x, element.y, element.w, element.h);
    }

    if (element.tool === "circle") {
      ctx.beginPath();
      ctx.ellipse(
        element.x + element.w / 2,
        element.y + element.h / 2,
        Math.abs(element.w / 2),
        Math.abs(element.h / 2),
        0,
        0,
        Math.PI * 2
      );
      ctx.stroke();
    }

    if (element.tool === "line") {
      ctx.beginPath();
      ctx.moveTo(element.x, element.y);
      ctx.lineTo(element.x + element.w, element.y + element.h);
      ctx.stroke();
    }

    if (element.tool === "text") {
      ctx.font = `${Math.max(18, (Number(element.size) || 4) * 4)}px Inter, Arial, sans-serif`;
      ctx.fillText(element.text || "", element.x, element.y);
    }

    ctx.restore();
  }, []);

  const renderCanvasNow = useCallback(() => {
    renderFrameRef.current = null;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Grid and elements are drawn on demand through requestAnimationFrame.
    ctx.fillStyle = darkMode ? "#151922" : "#fbfcff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = darkMode ? "rgba(255,255,255,.045)" : "rgba(15,23,42,.07)";
    ctx.lineWidth = 1;

    for (let x = 0; x < canvas.width; x += 48) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }

    for (let y = 0; y < canvas.height; y += 48) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    elementsRef.current.forEach((element) => drawElement(ctx, element));
    Object.values(remotePreviewsRef.current).forEach((element) => drawElement(ctx, element));
    drawElement(ctx, currentElementRef.current);
  }, [darkMode, drawElement]);

  const scheduleRender = useCallback(() => {
    if (renderFrameRef.current) return;
    renderFrameRef.current = requestAnimationFrame(renderCanvasNow);
  }, [renderCanvasNow]);

  useEffect(() => {
    scheduleRender();
  }, [darkMode, elements, scheduleRender]);

  useEffect(() => {
    return () => {
      if (renderFrameRef.current) cancelAnimationFrame(renderFrameRef.current);
    };
  }, []);

  const closePeerConnection = useCallback((peerId) => {
    const connection = peerConnectionsRef.current[peerId];
    if (connection) {
      connection.onicecandidate = null;
      connection.ontrack = null;
      connection.onconnectionstatechange = null;
      connection.getSenders().forEach((sender) => {
        try {
          connection.removeTrack(sender);
        } catch (error) {
          reportNonFatal("Peer sender cleanup failed", error);
        }
      });
      connection.close();
      delete peerConnectionsRef.current[peerId];
    }

    setRemoteStreams((streams) => {
      const next = { ...streams };
      delete next[peerId];
      return next;
    });
  }, []);

  const stopLocalMedia = useCallback(() => {
    localStreamRef.current?.getTracks().forEach((track) => track.stop());
    localStreamRef.current = null;
    if (localVideoRef.current) localVideoRef.current.srcObject = null;
    setMediaState((state) => ({
      ...state,
      mic: false,
      camera: false,
      sharing: false,
    }));
  }, []);

  const leaveCurrentRoom = useCallback((disconnect = false) => {
    if (joinedRef.current) socket.emit("leave-room", roomRef.current);
    Object.keys(peerConnectionsRef.current).forEach(closePeerConnection);
    stopLocalMedia();
    remotePreviewsRef.current = {};
    currentElementRef.current = null;
    setRemoteStreams({});
    setCursors({});
    setJoined(false);
    setStatus(disconnect ? "Disconnected" : "Left room");
    joinedRef.current = false;
    if (disconnect && socket.connected) socket.disconnect();
  }, [closePeerConnection, stopLocalMedia]);

  const joinCurrentRoom = useCallback(() => {
    if (!joinedRef.current || !socket.connected) return;
    socket.emit("join-room", {
      roomId: roomRef.current,
      name: profileRef.current.name,
      avatar: profileRef.current.avatar,
    });
  }, []);

  const createPeerConnection = useCallback((peerId) => {
    if (peerConnectionsRef.current[peerId]) return peerConnectionsRef.current[peerId];
    if (!window.RTCPeerConnection) {
      throw new Error("WebRTC is not available in this browser");
    }

    const connection = new RTCPeerConnection({ iceServers: ICE_SERVERS });
    peerConnectionsRef.current[peerId] = connection;

    localStreamRef.current?.getTracks().forEach((track) => {
      connection.addTrack(track, localStreamRef.current);
    });

    connection.onicecandidate = (event) => {
      if (event.candidate) {
        socket.emit("webrtc-ice-candidate", {
          roomId: roomRef.current,
          to: peerId,
          candidate: event.candidate,
        });
      }
    };

    connection.ontrack = (event) => {
      setRemoteStreams((streams) => ({ ...streams, [peerId]: event.streams[0] }));
    };

    connection.onconnectionstatechange = () => {
      if (["failed", "closed", "disconnected"].includes(connection.connectionState)) {
        closePeerConnection(peerId);
      }
    };

    return connection;
  }, [closePeerConnection]);

  const callPeer = useCallback(async (peerId) => {
    try {
      const connection = createPeerConnection(peerId);
      const offer = await connection.createOffer();
      await connection.setLocalDescription(offer);
      socket.emit("webrtc-offer", { roomId: roomRef.current, to: peerId, offer });
    } catch (error) {
      setErrorMessage(reportNonFatal("Unable to start peer call", error));
    }
  }, [createPeerConnection]);

  useEffect(() => {
    const handleWindowError = (event) => {
      setErrorMessage(event.message || "A runtime error was handled.");
    };
    const handleRejection = (event) => {
      setErrorMessage(reportNonFatal("Unhandled async operation", event.reason));
      event.preventDefault();
    };

    window.addEventListener("error", handleWindowError);
    window.addEventListener("unhandledrejection", handleRejection);

    return () => {
      window.removeEventListener("error", handleWindowError);
      window.removeEventListener("unhandledrejection", handleRejection);
    };
  }, []);

  useEffect(() => {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return undefined;

    const cleanups = [];
    const watchStream = (id, stream) => {
      if (!stream?.getAudioTracks().length) return;

      try {
        const audioContext = new AudioContext();
        const analyser = audioContext.createAnalyser();
        const source = audioContext.createMediaStreamSource(stream);
        const samples = new Uint8Array(analyser.frequencyBinCount);
        let frameId;

        audioContext.resume?.().catch((error) => reportNonFatal("Audio monitor resume failed", error));
        source.connect(analyser);

        const tick = () => {
          analyser.getByteFrequencyData(samples);
          const level = samples.reduce((sum, value) => sum + value, 0) / samples.length;
          if (level > 12) setActiveSpeaker(id);
          frameId = requestAnimationFrame(tick);
        };

        tick();
        cleanups.push(() => {
          cancelAnimationFrame(frameId);
          source.disconnect();
          audioContext.close().catch((error) => reportNonFatal("Audio monitor close failed", error));
        });
      } catch (error) {
        reportNonFatal("Audio monitor unavailable", error);
      }
    };

    watchStream(socket.id, localStreamRef.current);
    Object.entries(remoteStreams).forEach(([id, stream]) => watchStream(id, stream));

    return () => cleanups.forEach((cleanup) => cleanup());
  }, [remoteStreams, mediaState.mic, mediaState.sharing]);

  useEffect(() => {
    const handleConnect = () => {
      console.debug("[socket] connected", socket.id);
      setStatus("Connected");
      setErrorMessage("");
      joinCurrentRoom();
    };

    const handleDisconnect = () => {
      console.debug("[socket] disconnected");
      setStatus("Reconnecting...");
      setParticipants([]);
      setCursors({});
    };

    const handleConnectError = (error) => {
      console.debug("[socket] connection error", error);
      setStatus("Connection issue");
      setErrorMessage(reportNonFatal("Socket connection failed", error));
    };

    const handleRoomState = ({ participants: roomParticipants = [], elements: roomElements = [], messages: roomMessages = [] }) => {
      setParticipants(roomParticipants);
      setRoomElements(roomElements);
      setMessages(roomMessages);
      remotePreviewsRef.current = {};
      scheduleRender();
    };

    const handleParticipants = (roomParticipants = []) => {
      setParticipants(roomParticipants);
      setRemoteStreams((streams) =>
        Object.fromEntries(
          Object.entries(streams).filter(([id]) =>
            roomParticipants.some((participant) => participant.id === id)
          )
        )
      );
    };

    const handleParticipantJoined = safeAsync("Participant join handling failed", async (participant) => {
      setParticipants((current) =>
        current.some((user) => user.id === participant.id) ? current : [...current, participant]
      );
      if (localStreamRef.current && participant.id !== socket.id) {
        await callPeer(participant.id);
      }
    });

    const handleParticipantLeft = (peerId) => {
      closePeerConnection(peerId);
      setCursors((current) => {
        const next = { ...current };
        delete next[peerId];
        return next;
      });
      delete remotePreviewsRef.current[peerId];
      scheduleRender();
    };

    const handleElementCommitted = ({ element, authorId }) => {
      if (!element?.id) return;
      console.debug("[draw receive] commit", {
        id: element.id,
        authorId,
        tool: element.tool,
        points: element.points?.length || 0,
      });
      if (currentElementRef.current?.id === element.id) currentElementRef.current = null;
      if (authorId) delete remotePreviewsRef.current[authorId];

      const exists = elementsRef.current.some((item) => item.id === element.id);
      const nextElements = exists
        ? elementsRef.current.map((item) => (item.id === element.id ? element : item))
        : [...elementsRef.current, element];
      setRoomElements(nextElements);
      scheduleRender();
    };

    const handleElementPreview = ({ element, authorId }) => {
      if (!element || authorId === socket.id) return;
      console.debug("[draw receive] preview", {
        id: element.id,
        authorId,
        tool: element.tool,
        points: element.points?.length || 0,
      });
      remotePreviewsRef.current[authorId] = element;
      scheduleRender();
    };

    const handleBoardState = ({ elements: roomElements = [] }) => {
      setRoomElements(roomElements);
      setRedoStack([]);
      remotePreviewsRef.current = {};
      currentElementRef.current = null;
      scheduleRender();
    };

    const handleChat = (message) => {
      setMessages((current) => (current.some((item) => item.id === message.id) ? current : [...current, message]));
    };

    const handleCursor = ({ id, cursor }) => {
      if (!id || id === socket.id) return;
      setCursors((current) => ({ ...current, [id]: cursor }));
    };

    const handleOffer = safeAsync("WebRTC offer handling failed", async ({ from, offer }) => {
      const connection = createPeerConnection(from);
      await connection.setRemoteDescription(new RTCSessionDescription(offer));
      const answer = await connection.createAnswer();
      await connection.setLocalDescription(answer);
      socket.emit("webrtc-answer", { roomId: roomRef.current, to: from, answer });
    });

    const handleAnswer = safeAsync("WebRTC answer handling failed", async ({ from, answer }) => {
      await peerConnectionsRef.current[from]?.setRemoteDescription(new RTCSessionDescription(answer));
    });

    const handleCandidate = safeAsync("WebRTC ICE handling failed", async ({ from, candidate }) => {
      if (peerConnectionsRef.current[from] && candidate) {
        await peerConnectionsRef.current[from].addIceCandidate(new RTCIceCandidate(candidate));
      }
    });

    socket.on("connect", handleConnect);
    socket.on("disconnect", handleDisconnect);
    socket.on("connect_error", handleConnectError);
    socket.on("room-state", handleRoomState);
    socket.on("participants", handleParticipants);
    socket.on("participant-joined", handleParticipantJoined);
    socket.on("participant-left", handleParticipantLeft);
    socket.on("whiteboard-element", handleElementCommitted);
    socket.on("whiteboard-preview", handleElementPreview);
    socket.on("board-state", handleBoardState);
    socket.on("chat-message", handleChat);
    socket.on("cursor-update", handleCursor);
    socket.on("webrtc-offer", handleOffer);
    socket.on("webrtc-answer", handleAnswer);
    socket.on("webrtc-ice-candidate", handleCandidate);

    return () => {
      socket.off("connect", handleConnect);
      socket.off("disconnect", handleDisconnect);
      socket.off("connect_error", handleConnectError);
      socket.off("room-state", handleRoomState);
      socket.off("participants", handleParticipants);
      socket.off("participant-joined", handleParticipantJoined);
      socket.off("participant-left", handleParticipantLeft);
      socket.off("whiteboard-element", handleElementCommitted);
      socket.off("whiteboard-preview", handleElementPreview);
      socket.off("board-state", handleBoardState);
      socket.off("chat-message", handleChat);
      socket.off("cursor-update", handleCursor);
      socket.off("webrtc-offer", handleOffer);
      socket.off("webrtc-answer", handleAnswer);
      socket.off("webrtc-ice-candidate", handleCandidate);
    };
  }, [callPeer, closePeerConnection, createPeerConnection, joinCurrentRoom, scheduleRender, setRoomElements]);

  useEffect(() => {
    return () => leaveCurrentRoom(true);
  }, [leaveCurrentRoom]);

  const joinRoom = (event) => {
    event.preventDefault();
    const cleanRoomId = roomId.trim() || makeId();
    const cleanName = displayName.trim() || "Guest Collaborator";

    setStatus("Joining...");
    setErrorMessage("");
    setRoomId(cleanRoomId);
    setDisplayName(cleanName);
    localStorage.setItem("whiteboard-name", cleanName);
    roomRef.current = cleanRoomId;
    profileRef.current = { name: cleanName, avatar: avatarFor(cleanName) };
    joinedRef.current = true;
    setJoined(true);
    window.history.replaceState(null, "", `?room=${encodeURIComponent(cleanRoomId)}`);

    if (!socket.connected) socket.connect();
    socket.emit("join-room", {
      roomId: cleanRoomId,
      name: cleanName,
      avatar: avatarFor(cleanName),
    });
  };

  const publishBoard = useCallback((nextElements) => {
    socket.emit("whiteboard-sync", { roomId: roomRef.current, elements: nextElements });
  }, []);

  const commitElement = useCallback((element) => {
    const nextElements = [...elementsRef.current, element];
    setRoomElements(nextElements);
    setRedoStack([]);
    currentElementRef.current = null;
    scheduleRender();
    console.debug("[draw emit] commit", {
      id: element.id,
      roomId: roomRef.current,
      tool: element.tool,
      points: element.points?.length || 0,
    });
    socket.emit("whiteboard-element", { roomId: roomRef.current, element });
  }, [scheduleRender, setRoomElements]);

  const startMedia = async (kind) => {
    try {
      if (!navigator.mediaDevices) throw new Error("Camera and microphone APIs are not available");

      const stream =
        kind === "screen"
          ? await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true })
          : await navigator.mediaDevices.getUserMedia({ video: true, audio: true });

      stopLocalMedia();
      localStreamRef.current = stream;
      if (localVideoRef.current) localVideoRef.current.srcObject = stream;

      Object.values(peerConnectionsRef.current).forEach((connection) => {
        connection.getSenders().forEach((sender) => {
          try {
            connection.removeTrack(sender);
          } catch (error) {
            reportNonFatal("Sender replacement failed", error);
          }
        });
        stream.getTracks().forEach((track) => connection.addTrack(track, stream));
      });

      stream.getVideoTracks()[0]?.addEventListener("ended", () => {
        setMediaState((state) => ({ ...state, camera: false, sharing: false }));
        socket.emit("media-state", { roomId: roomRef.current, state: { camera: false, sharing: false } });
      });

      const nextMediaState = {
        mic: stream.getAudioTracks().some((track) => track.enabled),
        camera: kind !== "screen",
        sharing: kind === "screen",
      };

      setMediaState((state) => ({ ...state, ...nextMediaState }));
      socket.emit("media-state", { roomId: roomRef.current, state: nextMediaState });
      await Promise.all(participantsRef.current.filter((user) => user.id !== socket.id).map((user) => callPeer(user.id)));
    } catch (error) {
      setErrorMessage(reportNonFatal("Media unavailable", error));
    }
  };

  const toggleMic = async () => {
    try {
      if (!localStreamRef.current) {
        await startMedia("camera");
        return;
      }

      const nextMic = !mediaState.mic;
      localStreamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = nextMic;
      });
      setMediaState((state) => ({ ...state, mic: nextMic }));
      socket.emit("media-state", { roomId: roomRef.current, state: { mic: nextMic } });
    } catch (error) {
      setErrorMessage(reportNonFatal("Microphone toggle failed", error));
    }
  };

  const toggleCamera = async () => {
    try {
      if (!localStreamRef.current) {
        await startMedia("camera");
        return;
      }

      const nextCamera = !mediaState.camera;
      localStreamRef.current.getVideoTracks().forEach((track) => {
        track.enabled = nextCamera;
      });
      setMediaState((state) => ({ ...state, camera: nextCamera, sharing: false }));
      socket.emit("media-state", { roomId: roomRef.current, state: { camera: nextCamera, sharing: false } });
    } catch (error) {
      setErrorMessage(reportNonFatal("Camera toggle failed", error));
    }
  };

  const shareScreen = () => {
    startMedia("screen").catch((error) => setErrorMessage(reportNonFatal("Screen share failed", error)));
  };

  const handlePointerDown = (event) => {
    if (!joinedRef.current || !canvasRef.current) return;
    event.preventDefault();
    event.currentTarget.setPointerCapture?.(event.pointerId);
    const point = getCanvasPoint(event, canvasRef.current);

    if (tool === "pan") {
      panRef.current = { startX: event.clientX, startY: event.clientY, view: viewRef.current };
      return;
    }

    if (tool === "text") {
      const text = window.prompt("Add text to whiteboard");
      if (text?.trim()) {
        commitElement({ id: makeId(), tool, color, size: strokeSize, x: point.x, y: point.y, text: text.trim() });
      }
      return;
    }

    currentElementRef.current =
      tool === "pen" || tool === "eraser"
        ? { id: makeId(), tool, color, size: strokeSize, points: [point] }
        : { id: makeId(), tool, color, size: strokeSize, x: point.x, y: point.y, w: 0, h: 0 };
    scheduleRender();
  };

  const handlePointerMove = (event) => {
    if (!canvasRef.current) return;

    const now = performance.now();
    if (joinedRef.current && now - cursorThrottleRef.current > 45) {
      cursorThrottleRef.current = now;
      socket.emit("cursor-update", {
        roomId: roomRef.current,
        cursor: getCanvasPoint(event, canvasRef.current),
      });
    }

    if (panRef.current) {
      setView({
        ...panRef.current.view,
        x: panRef.current.view.x + event.clientX - panRef.current.startX,
        y: panRef.current.view.y + event.clientY - panRef.current.startY,
      });
      return;
    }

    if (!currentElementRef.current) return;
    event.preventDefault();
    const point = getCanvasPoint(event, canvasRef.current);
    const element = currentElementRef.current;

    if (element.tool === "pen" || element.tool === "eraser") {
      const lastPoint = element.points[element.points.length - 1];
      const distance = Math.hypot(point.x - lastPoint.x, point.y - lastPoint.y);
      if (distance < 2) return;
      element.points = [...element.points, point];
    } else {
      element.w = point.x - element.x;
      element.h = point.y - element.y;
    }

    currentElementRef.current = { ...element };
    console.debug("[draw emit] preview", {
      id: currentElementRef.current.id,
      roomId: roomRef.current,
      tool: currentElementRef.current.tool,
      points: currentElementRef.current.points?.length || 0,
    });
    socket.emit("whiteboard-preview", { roomId: roomRef.current, element: currentElementRef.current });
    scheduleRender();
  };

  const handlePointerUp = (event) => {
    event.currentTarget.releasePointerCapture?.(event.pointerId);
    panRef.current = null;
    if (currentElementRef.current) commitElement(currentElementRef.current);
  };

  const undo = () => {
    const current = elementsRef.current;
    if (!current.length) return;
    const next = current.slice(0, -1);
    const removed = current[current.length - 1];
    setRedoStack((stack) => [removed, ...stack]);
    setRoomElements(next);
    publishBoard(next);
    scheduleRender();
  };

  const redo = () => {
    setRedoStack((stack) => {
      if (!stack.length) return stack;
      const [restored, ...rest] = stack;
      const next = [...elementsRef.current, restored];
      setRoomElements(next);
      publishBoard(next);
      scheduleRender();
      return rest;
    });
  };

  const clearBoard = () => {
    setRoomElements([]);
    setRedoStack([]);
    remotePreviewsRef.current = {};
    console.debug("[draw emit] clear", { roomId: roomRef.current });
    socket.emit("clear-board", roomRef.current);
    scheduleRender();
  };

  const downloadBoard = () => {
    try {
      const link = document.createElement("a");
      link.download = `${roomRef.current}-whiteboard.png`;
      link.href = canvasRef.current.toDataURL("image/png");
      link.click();
    } catch (error) {
      setErrorMessage(reportNonFatal("Board download failed", error));
    }
  };

  const sendMessage = (event) => {
    event.preventDefault();
    const text = messageDraft.trim();
    if (!text) return;
    socket.emit("chat-message", { roomId: roomRef.current, text });
    setMessageDraft("");
  };

  const copyRoomLink = async () => {
    try {
      if (!navigator.clipboard?.writeText) {
        window.prompt("Copy room link", roomLink);
        return;
      }
      await navigator.clipboard.writeText(roomLink);
      setStatus("Link copied");
    } catch (error) {
      setErrorMessage(reportNonFatal("Clipboard copy failed", error));
      window.prompt("Copy room link", roomLink);
    }
  };

  const toggleHand = () => {
    const hand = !mediaState.hand;
    setMediaState((state) => ({ ...state, hand }));
    socket.emit("raise-hand", { roomId: roomRef.current, hand });
  };

  const videoTiles = [
    {
      id: socket.id || "local",
      name: `${displayName} (You)`,
      stream: localStreamRef.current,
      muted: true,
      active: activeSpeaker === socket.id,
    },
    ...participants
      .filter((user) => user.id !== socket.id)
      .map((user) => ({
        id: user.id,
        name: user.name,
        stream: remoteStreams[user.id],
        active: activeSpeaker === user.id,
      })),
  ];

  if (!joined) {
    return (
      <main className={`entry ${darkMode ? "theme-dark" : "theme-light"}`}>
        <section className="entry__panel">
          <div>
            <p className="eyebrow">Real-Time Collaborative Interactive Whiteboard</p>
            <h1>Launch a workspace where video, chat, and canvas move together.</h1>
            <p className="entry__copy">Join as a guest, share a room link, and collaborate live without setup friction.</p>
          </div>
          <form className="entry__form" onSubmit={joinRoom}>
            {errorMessage && <p className="notice error">{errorMessage}</p>}
            <label>
              Your name
              <input value={displayName} onChange={(event) => setDisplayName(event.target.value)} />
            </label>
            <label>
              Room code
              <input value={roomId} onChange={(event) => setRoomId(event.target.value)} />
            </label>
            <div className="entry__actions">
              <button type="submit">{status === "Joining..." ? "Joining..." : "Join room"}</button>
              <button type="button" onClick={() => setRoomId(makeId())}>Create new</button>
              <button type="button" onClick={() => setDarkMode((value) => !value)}>
                {darkMode ? "Light" : "Dark"} mode
              </button>
            </div>
          </form>
        </section>
      </main>
    );
  }

  return (
    <main className={`app ${darkMode ? "theme-dark" : "theme-light"}`}>
      <header className="topbar">
        <div>
          <p className="eyebrow">Room</p>
          <h1>{roomId}</h1>
        </div>
        <div className="status-pill" data-state={socket.connected ? "online" : "offline"}>
          <span />
          {status}
        </div>
        <div className="topbar__actions">
          <button onClick={copyRoomLink}>Share link</button>
          <button onClick={() => setDarkMode((value) => !value)}>{darkMode ? "Light" : "Dark"}</button>
          <button className="danger" onClick={() => leaveCurrentRoom(true)}>Leave</button>
        </div>
      </header>

      {errorMessage && (
        <button className="toast" onClick={() => setErrorMessage("")}>
          {errorMessage}
        </button>
      )}

      <section className="workspace">
        <aside className="toolrail">
          {TOOLS.map((item) => (
            <button key={item} className={tool === item ? "active" : ""} title={item} onClick={() => setTool(item)}>
              {item[0].toUpperCase()}
            </button>
          ))}
          <input aria-label="Stroke color" type="color" value={color} onChange={(event) => setColor(event.target.value)} />
          <input
            aria-label="Stroke size"
            className="size"
            type="range"
            min="2"
            max="28"
            value={strokeSize}
            onChange={(event) => setStrokeSize(Number(event.target.value))}
          />
          <div className="swatches">
            {COLORS.map((swatch) => (
              <button key={swatch} style={{ background: swatch }} title={swatch} onClick={() => setColor(swatch)} />
            ))}
          </div>
          <button onClick={undo}>Undo</button>
          <button onClick={redo}>Redo</button>
          <button onClick={clearBoard}>Clear</button>
          <button onClick={downloadBoard}>PNG</button>
        </aside>

        <div
          className="canvas-shell"
          onWheel={(event) => {
            event.preventDefault();
            const nextZoom = Math.min(1.7, Math.max(0.35, viewRef.current.zoom - event.deltaY * 0.001));
            setView((current) => ({ ...current, zoom: nextZoom }));
          }}
        >
          <canvas
            ref={canvasRef}
            width={CANVAS_WIDTH}
            height={CANVAS_HEIGHT}
            style={{ transform: `translate(${view.x}px, ${view.y}px) scale(${view.zoom})` }}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={handlePointerUp}
            onPointerLeave={handlePointerUp}
          />
          {Object.entries(cursors)
            .filter(([id]) => id !== socket.id)
            .map(([id, cursor]) => {
              const user = participants.find((participant) => participant.id === id);
              return (
                <span
                  className="remote-cursor"
                  key={id}
                  style={{
                    transform: `translate(${view.x + cursor.x * view.zoom}px, ${view.y + cursor.y * view.zoom}px)`,
                    color: user?.color || "#38bdf8",
                  }}
                >
                  <i />
                  <b>{user?.name || "Guest"}</b>
                </span>
              );
            })}
        </div>

        <aside className="sidebar">
          <div className="tabs">
            <button className={activePanel === "chat" ? "active" : ""} onClick={() => setActivePanel("chat")}>Chat</button>
            <button className={activePanel === "people" ? "active" : ""} onClick={() => setActivePanel("people")}>People</button>
          </div>

          {activePanel === "chat" ? (
            <>
              <div className="messages">
                {messages.map((message) => (
                  <article key={message.id}>
                    <strong>{message.sender}</strong>
                    <time>{new Date(message.sentAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</time>
                    <p>{message.text}</p>
                  </article>
                ))}
              </div>
              <form className="composer" onSubmit={sendMessage}>
                <input value={messageDraft} onChange={(event) => setMessageDraft(event.target.value)} placeholder="Message room" />
                <button>Send</button>
              </form>
            </>
          ) : (
            <div className="people">
              {participants.map((participant) => (
                <article key={participant.id}>
                  <span style={{ background: participant.color }}>{participant.avatar}</span>
                  <div>
                    <strong>{participant.name}</strong>
                    <p>
                      {participant.role}
                      {participant.hand ? " - hand raised" : ""}
                      {participant.media?.sharing ? " - sharing" : ""}
                    </p>
                  </div>
                </article>
              ))}
            </div>
          )}
        </aside>
      </section>

      <section className="video-strip">
        <div className="video-grid">
          {videoTiles.map((tile, index) => (
            <VideoTile key={tile.id} tile={tile} index={index} localRef={tile.muted ? localVideoRef : undefined} />
          ))}
        </div>
        <nav className="callbar">
          <button className={mediaState.mic ? "on" : ""} onClick={toggleMic}>{mediaState.mic ? "Mute" : "Mic"}</button>
          <button className={mediaState.camera ? "on" : ""} onClick={toggleCamera}>{mediaState.camera ? "Camera off" : "Camera"}</button>
          <button className={mediaState.sharing ? "on" : ""} onClick={shareScreen}>Share</button>
          <button className={mediaState.hand ? "on" : ""} onClick={toggleHand}>Raise hand</button>
          <button className="danger" onClick={() => leaveCurrentRoom(true)}>End</button>
        </nav>
      </section>
    </main>
  );
}

function VideoTile({ tile, localRef, index }) {
  const ref = useRef(null);

  useEffect(() => {
    const node = localRef?.current || ref.current;
    if (node) node.srcObject = tile.stream || null;
  }, [localRef, tile.stream]);

  return (
    <article className={`video-tile ${tile.active ? "speaking" : ""}`}>
      {tile.stream ? (
        <video ref={localRef || ref} autoPlay playsInline muted={tile.muted} />
      ) : (
        <div className="video-placeholder">{avatarFor(tile.name)}</div>
      )}
      <span>{tile.name}</span>
      {index === 0 && <small>Local preview</small>}
    </article>
  );
}

export default App;
