# Real-Time Collaborative Interactive Whiteboard

A full-stack collaborative meeting workspace with a Zoom/Google Meet-inspired interface, real-time whiteboard, WebRTC video rooms, live chat, participants, dark/light theme, and room sharing.

## Features

- Infinite-style pan and zoom whiteboard canvas
- Pen, eraser, rectangle, circle, line, and text tools
- Color swatches, color picker, stroke size, clear, undo, redo, and PNG export
- Socket.io synchronization for board updates, live cursors, chat, participants, and room state
- WebRTC peer signaling for camera, microphone, and screen sharing
- Meeting-style video strip, call controls, participant list, raise hand, and chat sidebar
- Guest room flow with shareable links
- Responsive premium SaaS-style UI with dark and light modes

## Project Structure

```text
client/   React app
server/   Express + Socket.io realtime server
```

## Run Locally

Start the backend:

```bash
cd server
npm install
npm start
```

Start the frontend in another terminal:

```bash
cd client
npm install
npm start
```

The client defaults to `http://localhost:5000` for Socket.io. For hosted deployments, set `REACT_APP_SOCKET_URL` before building the client.

## Deployment

- Frontend: deploy `client` to Vercel, Netlify, or any static host.
- Backend: deploy `server` to Render, Railway, Fly.io, or another Node host.
- Set `CLIENT_ORIGIN` on the backend to the frontend URL.
- Set `REACT_APP_SOCKET_URL` on the frontend to the backend URL.

The current server uses in-memory room state so it is easy to run and demo. To persist sessions across restarts or multiple backend instances, replace the `rooms` map in `server/server.js` with MongoDB-backed room, message, and board models.
